package com.edingyc.bcxzs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BcxzsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BcxzsApplication.class, args);
	}
}
