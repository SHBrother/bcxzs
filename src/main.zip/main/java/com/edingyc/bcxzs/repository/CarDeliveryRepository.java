package com.edingyc.bcxzs.repository;

import com.edingyc.bcxzs.dataEntity.CarDeliveryEntity;
import com.edingyc.bcxzs.dto.CarTransportDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


public interface CarDeliveryRepository   extends JpaRepository<CarDeliveryEntity, String> {

    String baseSQL = "SELECT new com.edingyc.bcxzs.dto.CarTransportDTO( cd.id,cd.vin,cd.brand,cr.id,cd.deliveryTime,cd.deliveryAddr,cr.receiveTime,cr.receiveAddr) " +
                     "FROM CarDeliveryEntity cd " +
                     "LEFT JOIN CarReceiveHistoryEntity cr ON cr.vin = cd.vin ";
    @Query( baseSQL+"WHERE cd.id = ?1")
    CarTransportDTO findByDeliveryId(String id);

    @Query(baseSQL)
    Page<CarTransportDTO> findByUserId(String userId,Pageable pageable);

    CarDeliveryEntity findByVinAndUserId(String vin,String userId);

}
