package com.edingyc.bcxzs.repository;

import com.edingyc.bcxzs.dataEntity.CarShareEntity;
import com.edingyc.bcxzs.dto.CarShareDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;

public interface CarShareRepository   extends JpaRepository<CarShareEntity, String> {

    void deleteByVinAndDriverId(String vin,String driverId);

    Page<CarShareEntity> findByDispatcherIdAAndFileFlag(String dispatcherId, Pageable pageable,int fileFlag);

    @Modifying
    @Query("UPDATE tab_bcxzs_car_share SET delegate_company = ?2,fee=?3,settle_date=?4,delivery_addr=?5,delivery_time=?6,file_flag=1 WHERE id=?1")
    void updateCarShare(String id, String delegateCompany, String fee, Date settleDate, String deliveryAddr, Date deliveryTime);

    Page<CarShareEntity> findAll(Specification<CarShareEntity> specification, Pageable pageable);



}
