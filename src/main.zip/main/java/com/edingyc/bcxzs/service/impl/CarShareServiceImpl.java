package com.edingyc.bcxzs.service.impl;

import com.edingyc.bcxzs.Utils.EbusRequestSession;
import com.edingyc.bcxzs.Utils.convert.ConvertUtil;
import com.edingyc.bcxzs.Utils.randomId.IDGenerator;
import com.edingyc.bcxzs.dataEntity.*;
import com.edingyc.bcxzs.dto.CarShareDTO;
import com.edingyc.bcxzs.exception.WrapException;
import com.edingyc.bcxzs.repository.*;
import com.edingyc.bcxzs.service.CarShareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class CarShareServiceImpl implements CarShareService{

    @Autowired
    UserRelationRepository userRelationRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    IDGenerator idGenerator;
    @Autowired
    CarReceiveRepository carReceiveRepository;
    @Autowired
    CarDeliveryRepository carDeliveryRepository;
    @Autowired
    CarShareRepository carShareRepository;

    @Override
    public void unionId(String dispatcherId){
        UserRelationEntity userRelationEntity = new UserRelationEntity();
        String  driverId = EbusRequestSession.getExHeader(EbusRequestSession.HEADER_USERID);
        userRelationEntity.setDriverId(driverId);
        userRelationEntity.setDispatcherId(dispatcherId);
        userRelationEntity.setId(idGenerator.generateRamdomID());
        userRelationRepository.save(userRelationEntity);
    }

    @Override
    public List<UserEntity> getDispatcherInfo() {
        String  driverId = EbusRequestSession.getExHeader(EbusRequestSession.HEADER_USERID);
        List<UserRelationEntity> userRelationEntityList = userRelationRepository.findByDriverId(driverId);
        List<UserEntity> userEntityList = new ArrayList<>();
        userRelationEntityList.forEach(userRelationEntity -> {
            Optional<UserEntity> optionalUserEntity =  userRepository.findById(userRelationEntity.getDispatcherId());
            userEntityList.add(optionalUserEntity.get());
        });
        return userEntityList;
    }

    @Override
    public void carReceiveShare(String id, String dispatcherId) throws WrapException{
        Optional<CarReceiveEntity> optionalCarReceiveEntity = carReceiveRepository.findById(id);
        CarReceiveEntity carReceiveEntity = optionalCarReceiveEntity.get();
        CarShareEntity carSharedEntity =  ConvertUtil.convert(carReceiveEntity,CarShareEntity.class);

        String driverId = EbusRequestSession.getExHeader(EbusRequestSession.HEADER_USERID);
        carSharedEntity.setDriverId(driverId);
        carSharedEntity.setDispatcherId(dispatcherId);

        carShareRepository.save(carSharedEntity);
    }

    @Override
    public void carDeliveryShare(String id, String dispatcherId)  throws WrapException{
        Optional<CarDeliveryEntity> optionalCarDeliveryEntity = carDeliveryRepository.findById(id);
        CarDeliveryEntity carDeliveryEntity = optionalCarDeliveryEntity.get();
        CarShareEntity carSharedEntity = ConvertUtil.convert(carDeliveryEntity,CarShareEntity.class);

        String driverId = EbusRequestSession.getExHeader(EbusRequestSession.HEADER_USERID);
        carSharedEntity.setDriverId(driverId);
        carSharedEntity.setDispatcherId(dispatcherId);

        String vin = carSharedEntity.getVin();
        if (!StringUtils.isEmpty(vin)){
            carShareRepository.deleteByVinAndDriverId(vin,driverId);
        }

        carShareRepository.save(carSharedEntity);
    }

    @Override
    public List<CarShareDTO> findCarShareList(Pageable pageable) throws WrapException{
        String userId = EbusRequestSession.getExHeader(EbusRequestSession.HEADER_USERID);
        Page<CarShareEntity> carShareEntityPage = carShareRepository.findByDispatcherIdAAndFileFlag(userId,pageable,0);
        List<CarShareEntity> carShareEntityList = carShareEntityPage.getContent();
        return ConvertUtil.convert(carShareEntityList,CarShareDTO.class);
    }

    @Override
    public CarShareDTO findCarShareDetail(String id) throws WrapException {
        Optional<CarShareEntity> optionalCarShareEntity = carShareRepository.findById(id);
        CarShareEntity carShareEntity = optionalCarShareEntity.get();
        return ConvertUtil.convert(carShareEntity,CarShareDTO.class);
    }

    @Override
    public void addCarFile(CarShareDTO carShareDTO) {
        carShareRepository.updateCarShare(carShareDTO.getId(),carShareDTO.getDelegateCompany(),carShareDTO.getFee(),carShareDTO.getSettleDate(),carShareDTO.getDeliveryAddr(),carShareDTO.getDeliveryTime());
    }

    @Override
    public List<CarShareDTO> findCarFileList(Pageable pageable,CarShareDTO carShareDTO) throws WrapException{

        Specification<CarShareEntity> specification = new Specification<CarShareEntity>(){
            @Override
            public Predicate toPredicate(Root root, CriteriaQuery criteriaQuery, CriteriaBuilder cb) {
                List<Predicate> predicateList = new ArrayList();
                if (!StringUtils.isEmpty(carShareDTO.getVin())){
                    predicateList.add(cb.equal(root.get("vin").as(String.class),carShareDTO.getVin()));
                }
                if (!StringUtils.isEmpty(carShareDTO.getDelegateCompany())){
                    predicateList.add(cb.like(root.get("delegate_company").as(String.class),"%"+carShareDTO.getDelegateCompany()+"%"));
                }
                if (!StringUtils.isEmpty(carShareDTO.getDeliveryTime())){
                    predicateList.add(cb.equal(root.get("delivery_time").as(Date.class),carShareDTO.getDeliveryTime()));
                }
                predicateList.add(cb.equal(root.get("file_flag").as(int.class),1));
                Predicate[] arrayPredicates = new Predicate[predicateList.size()];
                return cb.and(predicateList.toArray(arrayPredicates));
            }
        };
        Page<CarShareEntity> carShareEntityPage= carShareRepository.findAll(specification,pageable);
        List<CarShareDTO> carShareDTOList = ConvertUtil.convert(carShareEntityPage.getContent(),CarShareDTO.class);
        return carShareDTOList;

    }
}
