package com.edingyc.bcxzs.dto;

import com.edingyc.bcxzs.Utils.convert.IgnoreField;
import lombok.Data;

import java.util.Date;

@Data
public class CarShareDTO {

    @IgnoreField
    private static final long serialVersionUID = 1L;

    private String id;

    private String vin;

    private String brand;

    private Date receiveTime;

    private String receiveAddr;

    private Date deliveryTime;

    private String deliveryAddr;

    private String driverId;

    private String dispatcherId;

    private String delegateCompany;

    private String fee;

    private Date settleDate;

    private int fileFlag;

}
